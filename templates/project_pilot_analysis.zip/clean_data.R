# You should write code here to clean your pilot data and export it as a
# CSV file to the "data" folder
