# Assignment 1

# Type your name here: First Last

# .R files are used for writing R code that you want to run in the R console.
# If you want to write text that won't cause an error in the R console,
# you have to use comments, using the "#" symbol

# You can this file to work through any of the code you wish to for
# assignment 1. Use it to take notes, copy-paste code snippets from
# exercises, etc. Think of it like a scratch pad, but for code.

# When you've finished doing the readings and exercises,
# Leave your reflection in a series of comments at the bottom of this file.
